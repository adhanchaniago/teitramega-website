#Socicon

More information on [socicon.com](http://socicon.com/)

##The little story behind Socicon
Socicon was created to give people an easy way to customize social icons.  
**Made in France**  
In France we are very proud of our food (sometimes a bit too much)!   Socicon refers to the [saucisson](http://en.wikipedia.org/wiki/Saucisson), a sort of dry sausage that we eat as an aperitif with a drink, with cheese, in a packed lunch, well we can really eat saucisson any time, anywhere and with anyone!

##License

Socicon is released under SIL Open Font License 1.1 ([http://scripts.sil.org/OFL](http://scripts.sil.org/OFL)).  
You are free to use it on your website or project.  

###Commercial use
You can use Socicon on a commercial project (a product or service that you sell, make money out of it). You only have to credit Socicon with a backlink to socicon.com.  
You can use this:  
`Social icons font: <a href="http://www.socicon.com" target="_blank" alt="Free social icons font" title="the social icons font">socicon</a>`

##Share & Help

If you use Socicon for any project, please make a backlink to http://socicon.com somewhere in credits, imprint, legal notice.  
It will give us a hand and be highly appreciated.
You can also share Socicon on twitter, facebook, google+ or anywhere else.

You can also [make a donation](http://cut.lu/donation)